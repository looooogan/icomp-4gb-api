package com.common.utils.exception;

/**
 * Created by logan on 2018/5/5.
 */
public class ExceptionConstans {

    public static String MATERIALINVENTORY_CUTTINGTOOL_UNFOUND = "mc_001";


    public static String SYNTHESISCUTTINGTOOL_CONFIG_EXISTS = "sctc_001";


    public static String CUTTINGTOOL_NOT_EXISTS = "ctne_001";


    public static String RFID_NOT_EXISTS = "rfid_001";


    public static String QM_SUSR20_UNITQTY_CHANGE_ERROR = "qm_001";

}
