package com.common.pojo;

import java.io.Serializable;

/**
* Created by jiangchenkeji
* Automated Build
* 实体 QimingRecords 
*/
public class QimingRecords implements Serializable{

    // 序列化接口属性
    private static final long serialVersionUID = 1L;
    /**
     * @fieldName id
    * @fieldType  Integer
    * @Description  id
     */
    private Integer id;

    /**
     * @fieldName applyNo
    * @fieldType  String
    * @Description  启明出库单号
     */
    private String applyNo;
    /**
     * @fieldName unitqty
    * @fieldType  String
    * @Description  出库数量
     */
    private String unitqty;
    /**
     * @fieldName mtlCode
    * @fieldType  String
    * @Description  物料号
     */
    private String mtlCode;
    /**
     * @fieldName loc
    * @fieldType  String
    * @Description  刀具号
     */
    private String loc;
    /**
     * @fieldName batchNo
    * @fieldType  Integer
    * @Description  批次
     */
    private Integer batchNo;
    /**
     * @fieldName cuttingToolCode
    * @fieldType  String
    * @Description  材料刀号
     */
    private String cuttingToolCode;
    /**
     * @fieldName cuttingToolBindCode
    * @fieldType  String
    * @Description  材料刀绑定
     */
    private String cuttingToolBindCode;
    /**
     * @fieldName bladeCode
    * @fieldType  String
    * @Description  刀身码
     */
    private String bladeCode;
    /**
     * @fieldName isDel
    * @fieldType  Integer
    * @Description  逻辑删除
     */
    private Integer isDel;




    /* id */
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getApplyNo() {
        return applyNo;
    }

    public void setApplyNo(String applyNo) {
        this.applyNo = applyNo;
    }
    public String getUnitqty() {
        return unitqty;
    }

    public void setUnitqty(String unitqty) {
        this.unitqty = unitqty;
    }
    public String getMtlCode() {
        return mtlCode;
    }

    public void setMtlCode(String mtlCode) {
        this.mtlCode = mtlCode;
    }
    public String getLoc() {
        return loc;
    }

    public void setLoc(String loc) {
        this.loc = loc;
    }
    public Integer getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(Integer batchNo) {
        this.batchNo = batchNo;
    }
    public String getCuttingToolCode() {
        return cuttingToolCode;
    }

    public void setCuttingToolCode(String cuttingToolCode) {
        this.cuttingToolCode = cuttingToolCode;
    }
    public String getCuttingToolBindCode() {
        return cuttingToolBindCode;
    }

    public void setCuttingToolBindCode(String cuttingToolBindCode) {
        this.cuttingToolBindCode = cuttingToolBindCode;
    }
    public String getBladeCode() {
        return bladeCode;
    }

    public void setBladeCode(String bladeCode) {
        this.bladeCode = bladeCode;
    }
    public Integer getIsDel() {
        return isDel;
    }

    public void setIsDel(Integer isDel) {
        this.isDel = isDel;
    }



}
