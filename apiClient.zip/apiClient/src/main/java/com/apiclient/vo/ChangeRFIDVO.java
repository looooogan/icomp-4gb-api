package com.apiclient.vo;

/**
 * Created by logan on 2018/5/6.
 */
public class ChangeRFIDVO {


    private String rfidCode;

    private String toolCode;

    public String getRfidCode() {
        return rfidCode;
    }

    public void setRfidCode(String rfidCode) {
        this.rfidCode = rfidCode;
    }

    public String getToolCode() {
        return toolCode;
    }

    public void setToolCode(String toolCode) {
        this.toolCode = toolCode;
    }
}
