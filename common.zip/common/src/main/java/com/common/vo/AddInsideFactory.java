package com.common.vo;

/**
 * Created by logan on 2018/5/6.
 */
public class AddInsideFactory {



}
