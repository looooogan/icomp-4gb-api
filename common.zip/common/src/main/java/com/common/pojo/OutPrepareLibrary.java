package com.common.pojo;

import java.io.Serializable;
import java.sql.Timestamp;

/**
* Created by jiangchenkeji
* Automated Build
* 实体 OutPrepareLibrary 
*/
public class OutPrepareLibrary implements Serializable{

    // 序列化接口属性
    private static final long serialVersionUID = 1L;
    /**
     * @fieldName id
    * @fieldType  Integer
    * @Description  出库id
     */
    private Integer id;

    /**
     * @fieldName date
    * @fieldType  Timestamp
    * @Description  出库时间
     */
    private Timestamp date;
    /**
     * @fieldName applicatName
    * @fieldType  String
    * @Description  申请人
     */
    private String applicatName;
    /**
     * @fieldName applicatCode
    * @fieldType  String
    * @Description  申请人code
     */
    private String applicatCode;
    /**
     * @fieldName count
    * @fieldType  Integer
    * @Description  出库数量
     */
    private Integer count;
    /**
     * @fieldName recipientName
    * @fieldType  String
    * @Description  领用人姓名
     */
    private String recipientName;
    /**
     * @fieldName recipientCode
    * @fieldType  String
    * @Description  领用人code
     */
    private String recipientCode;
    /**
     * @fieldName isDel
    * @fieldType  Integer
    * @Description  逻辑删除
     */
    private Integer isDel;
    /**
     * @fieldName cuttingToolCode
    * @fieldType  String
    * @Description  
     */
    private String cuttingToolCode;
    /**
     * @fieldName orderNum
    * @fieldType  String
    * @Description  单号
     */
    private String orderNum;
    /**
     * @fieldName cuttingToolBusinessCode
    * @fieldType  String
    * @Description  材料刀物料号
     */
    private String cuttingToolBusinessCode;
    /**
     * @fieldName status
    * @fieldType  String
    * @Description  状态 0未完成 1已完成
     */
    private String status;

    /**
     * @fieldName cuttingToolCode
    * @fieldType  
    * @Description  
     */
    private CuttingTool cuttingTool;



    /* 出库id */
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Timestamp getDate() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }
    public String getApplicatName() {
        return applicatName;
    }

    public void setApplicatName(String applicatName) {
        this.applicatName = applicatName;
    }
    public String getApplicatCode() {
        return applicatCode;
    }

    public void setApplicatCode(String applicatCode) {
        this.applicatCode = applicatCode;
    }
    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
    public String getRecipientName() {
        return recipientName;
    }

    public void setRecipientName(String recipientName) {
        this.recipientName = recipientName;
    }
    public String getRecipientCode() {
        return recipientCode;
    }

    public void setRecipientCode(String recipientCode) {
        this.recipientCode = recipientCode;
    }
    public Integer getIsDel() {
        return isDel;
    }

    public void setIsDel(Integer isDel) {
        this.isDel = isDel;
    }
    public String getCuttingToolCode() {
        return cuttingToolCode;
    }

    public void setCuttingToolCode(String cuttingToolCode) {
        this.cuttingToolCode = cuttingToolCode;
    }
    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }
    public String getCuttingToolBusinessCode() {
        return cuttingToolBusinessCode;
    }

    public void setCuttingToolBusinessCode(String cuttingToolBusinessCode) {
        this.cuttingToolBusinessCode = cuttingToolBusinessCode;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public CuttingTool getCuttingTool() {
        return cuttingTool;
    }

    public void setCuttingTool(CuttingTool cuttingTool) {
        this.cuttingTool = cuttingTool;
    }


}
