package com.common.auth;

/**
 * Created by logan on 2018/5/8.
 */
public class AuthInfo {

}
