package com.apiclient.vo;

/**
 * Created by logan on 2018/5/6.
 */
public class CuttingTollAddCodeVO {

    private String  searchCode;

    public String getSearchCode() {
        return searchCode;
    }

    public void setSearchCode(String searchCode) {
        this.searchCode = searchCode;
    }
}
