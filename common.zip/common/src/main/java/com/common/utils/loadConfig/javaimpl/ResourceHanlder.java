package com.common.utils.loadConfig.javaimpl;

import com.common.utils.loadConfig.IPropertiesHanlder;

/**
 * @ClassName: ResourceHanlder
 * @Description: java resourceBundle获取属性文件信息
 * @author: Jivoin
 * @date: 2014年7月26日 下午4:23:38
 */
public class ResourceHanlder implements IPropertiesHanlder {
	
	@Override
	public String getValue(String key) throws Exception {
		return null;
	}

	@Override
	public String[] getValues(String key) throws Exception {
		return null;
	}
	
	

}
