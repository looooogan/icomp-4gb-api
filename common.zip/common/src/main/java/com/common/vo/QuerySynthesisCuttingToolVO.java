package com.common.vo;

/**
 * Created by logan on 2018/5/6.
 */
public class QuerySynthesisCuttingToolVO {

    private String rfidCode;

    public String getRfidCode() {
        return rfidCode;
    }

    public void setRfidCode(String rfidCode) {
        this.rfidCode = rfidCode;
    }
}
