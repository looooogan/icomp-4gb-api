package com.apiclient.vo;

/**
 * Created by logan on 2018/5/6.
 */
public class SynthesisCuttingToolInitVO {

    private String rfidCode;

    private String synthesisCode;

    public String getRfidCode() {
        return rfidCode;
    }

    public void setRfidCode(String rfidCode) {
        this.rfidCode = rfidCode;
    }

    public String getSynthesisCode() {
        return synthesisCode;
    }

    public void setSynthesisCode(String synthesisCode) {
        this.synthesisCode = synthesisCode;
    }
}
